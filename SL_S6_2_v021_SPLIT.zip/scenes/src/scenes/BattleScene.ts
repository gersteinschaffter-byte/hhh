import type GameApp from '../core/GameApp';
import BaseScene from './BaseScene';
import BattleEngine from '../battle/BattleEngine';
import type { FighterSnapshot, Side } from '../battle/BattleTypes';
import UIButton from '../ui/components/UIButton';
import { createText } from '../ui/uiFactory';
import { HERO_MAP } from '../game/data';
import { ECONOMY, RARITY } from '../game/config';

/**
 * BattleScene
 *
 * Phase 6 goal (MVP+):
 * - Read player's owned heroes from GameState
 * - Generate battle stats based on hero level + rarity
 * - Generate simple enemies based on player's power
 * - On battle end, settle rewards through GameState + show popup (Popup layer via global Modal)
 */
export default class BattleScene extends BaseScene {
  private readonly game: GameApp;
  private readonly engine: BattleEngine;
  private readonly title;
  private readonly btnRestart;
  private readonly hint;

  private battleResolved = false;

  // Progress stage is a first-class field in GameState (v0.0.8+).

  // Boss chest drop rates (boss win only)
  private static readonly CHEST_PROB = [
    { key: 'chest_c', p: 0.6 },
    { key: 'chest_b', p: 0.25 },
    { key: 'chest_a', p: 0.12 },
    { key: 'chest_s', p: 0.03 },
  ] as const;

  // Simple, tuneable stat multipliers by rarity.
  private static readonly RARITY_MULT: Record<string, number> = {
    [RARITY.R]: 1.0,
    [RARITY.SR]: 1.25,
    [RARITY.SSR]: 1.6,
    [RARITY.SP]: 2.0,
  };

  constructor(game: GameApp) {
    super('battle');
    this.game = game;
    this.engine = new BattleEngine({ stepIntervalTicks: 32 });

    // Intercept battle end to trigger settlement (rewards + popup).
    const rawEmit = this.engine.emit.bind(this.engine);
    (this.engine as any).emit = (e: any) => {
      rawEmit(e);
      if (e?.type === 'battleEnd') {
        const winner: Side | 'Draw' = e.payload?.winner;
        this.onBattleEnd(winner);
      }
    };

    this.title = createText('战斗', 40, 0xffffff, '900');
    this.title.anchor.set(0.5);
    this.root.addChild(this.title);

    // Arena view
    this.root.addChild(this.engine.view.root);

    this.btnRestart = new UIButton('重新开始', 240, 78);
    this.btnRestart.on('pointertap', () => this.startBattleFromState());
    this.root.addChild(this.btnRestart);

    this.hint = createText('自动回合制：使用玩家队伍 + 胜利奖励 ✅', 18, 0xd7e6ff, '800');
    this.hint.anchor.set(0.5);
    this.root.addChild(this.hint);
  }

  public override onEnter(): void {
    // Hide bottom nav for better immersion; keep TopBar for back.
    this.game.bottomNav.visible = false;
    this.startBattleFromState();
  }

  public override onExit(): void {
    this.game.bottomNav.visible = true;
  }

  public override onResize(w: number, h: number): void {
    if (!this.title || (this.title as any).destroyed) return;
    this.title.position.set(w / 2, 170);
    // Arena is 720x900 inside view; place it centered
    const root: any = (this.engine as any)?.view?.root;
    if (root && !root.destroyed) root.position.set((w - 720) / 2, 240);
    if (this.btnRestart && !(this.btnRestart as any).destroyed) this.btnRestart.position.set((w - 240) / 2, h - 220);
    if (this.hint && !(this.hint as any).destroyed) this.hint.position.set(w / 2, h - 128);
  }

  public override onUpdate(dt: number): void {
    this.engine.update(dt);
  }

  private startBattleFromState(): void {
    this.battleResolved = false;

    const rawParty = [...(this.game.state.partyHeroIds ?? [])].slice(0, 5);
    if (rawParty.length < 1) {
      this.game.toast.show("请先上阵至少1名英雄", 2);
      this.game.goTo("home", { animate: false });
      return;
    }

    const ownedHeroes = rawParty
      .map((id) => this.game.state.getOwnedHero(id))
      .filter((h): h is any => !!h)
      .slice(0, 5);


    const validHeroes = ownedHeroes.filter((h) => !!HERO_MAP[h.heroId]);
    if (validHeroes.length !== validHeroes.length) {
      this.game.state.setPartyHeroIds(validHeroes.map((h) => h.heroId));
    }

    if (validHeroes.length < 1) {
      this.game.toast.show("队伍英雄无效，请重新上阵", 2);
      this.game.state.setPartyHeroIds([]);
      this.game.goTo("home", { animate: false });
      return;
    }


    const mk = (id: string, name: string, side: 'A' | 'B', hp: number, atk: number, spd: number): FighterSnapshot => ({
      id,
      name,
      side,
      hp,
      maxHp: hp,
      atk,
      spd,
    });

    // --- Team A: player's owned heroes ---
    const teamA: FighterSnapshot[] = validHeroes.map((o, idx) => {
      const def = HERO_MAP[o.heroId];
      // If data is missing for some reason, keep a safe fallback.
      const rarity = def?.rarity ?? RARITY.R;
      const name = def?.name ?? `英雄${idx + 1}`;
      const { hp, atk, spd } = this.genStats(o.level || 1, rarity);
      // Stars bonus (battle-only): mult = 1 + 0.10 * (stars - 1). Treat 0 as 1★ for backward compatibility.
      const stars = Math.max(1, o.stars || 0);
      const mult = 1 + 0.1 * (stars - 1);
      const hp2 = Math.round(hp * mult);
      const atk2 = Math.round(atk * mult);
      return mk(`p${idx + 1}:${o.heroId}`, name, 'A', hp2, atk2, spd);
    });

    // --- Team B: simple generated enemies ---
    const avgLv = Math.max(1, Math.round(validHeroes.reduce((s, h) => s + (h.level || 1), 0) / validHeroes.length));
    const enemyLv = Math.min(60, avgLv + 2);
    const enemyCount = 3;
    const teamB: FighterSnapshot[] = Array.from({ length: enemyCount }).map((_, i) => {
      // Enemies are slightly weaker in rarity but scale with level.
      const r = enemyLv >= 20 ? RARITY.SR : RARITY.R;
      const { hp, atk, spd } = this.genEnemyStats(enemyLv, r, i);
      return mk(`e${i + 1}`, `敌人${i + 1}`, 'B', hp, atk, spd);
    });

    this.engine.start({ teamA, teamB });
  }

  private getCurrentStage(): number {
    return this.game.state.stage;
  }

  private rollBossChest(stage: number): string {
    let r = Math.random();
    let picked = 'chest_c';
    for (const it of BattleScene.CHEST_PROB) {
      r -= it.p;
      if (r <= 0) {
        picked = it.key;
        break;
      }
    }
    // Pity: stage % 50 == 0 must be at least chest_a.
    if (stage % 50 === 0 && (picked === 'chest_c' || picked === 'chest_b')) {
      picked = 'chest_a';
    }
    return picked;
  }

  /**
   * Minimal stat generation (stable & tunable).
   * Ensures stats increase with level and rarity.
   */
  private genStats(level: number, rarity: string): { hp: number; atk: number; spd: number } {
    const lv = Math.max(1, Math.floor(level));
    const base = BattleScene.RARITY_MULT[rarity] ?? 1.0;
    const hp = Math.round(200 * base + lv * 40 * base);
    const atk = Math.round(30 * base + lv * 8 * base);
    const spd = Math.round(90 + lv * 1);
    return { hp, atk, spd };
  }

  /**
   * Enemy stats: scale with player's power (avg level + 2).
   * Slight random-ish variation per slot to avoid identical enemies.
   */
  private genEnemyStats(level: number, rarity: string, index: number): { hp: number; atk: number; spd: number } {
    const lv = Math.max(1, Math.floor(level));
    const base = (BattleScene.RARITY_MULT[rarity] ?? 1.0) * 0.95;
    const slotMul = 1 + (index - 1) * 0.06; // -6%, 0%, +6%
    const hp = Math.round((220 * base + lv * 42 * base) * slotMul);
    const atk = Math.round((28 * base + lv * 7.5 * base) * slotMul);
    const spd = Math.round(88 + lv * 1 + index);
    return { hp, atk, spd };
  }

  private onBattleEnd(winner: Side | 'Draw'): void {
    if (this.battleResolved) return;
    this.battleResolved = true;

    const modal = this.game.modal;
    modal.content.removeChildren();

    const panelW = modal.panel.width;
    const panelH = modal.panel.height;

    const isWin = winner === 'A';
    const title = createText(isWin ? '胜利！' : winner === 'B' ? '失败' : '平局', 44, 0xffffff, '900');
    title.anchor.set(0.5);
    title.position.set(panelW / 2, 86);

    // Reward settlement must go through GameState (data-driven UI refresh).
    const lines: string[] = [];
    const stage = this.getCurrentStage();
    const isBoss = stage % 10 === 0;
    if (isWin) {
      const ownedHeroes = [...this.game.state.heroes].slice(0, 3);
      const avgLv = Math.max(1, Math.round(validHeroes.reduce((s, h) => s + (h.level || 1), 0) / validHeroes.length));

      const gold = Math.max(20, 60 + avgLv * 18);
      this.game.state.addGold(gold);
      lines.push(`金币 +${gold}`);

      // Advance stage after win.
      this.game.state.advanceStage(1);

      if (isBoss) {
        // Diamonds & shards (dupe shards)
        const diamonds = Math.max(10, 20 + Math.floor(stage / 10) * 5);
        const shards = Math.max(2, 6 + Math.floor(stage / 10));
        this.game.state.addDiamonds(diamonds);
        this.game.state.addInventory(ECONOMY.dupeShardKey, shards);
        lines.push(`钻石 +${diamonds}`);
        lines.push(`万能碎片 +${shards}`);

        const chestKey = this.rollBossChest(stage);
        this.game.state.addInventory(chestKey, 1);
        const econ = ECONOMY as any;
        const chestName =
          chestKey === 'chest_c'
            ? econ.chest_cName ?? '普通宝箱'
            : chestKey === 'chest_b'
              ? econ.chest_bName ?? '高级宝箱'
              : chestKey === 'chest_a'
                ? econ.chest_aName ?? '史诗宝箱'
                : econ.chest_sName ?? '传说宝箱';
        lines.push(`宝箱：${chestName} x1`);
      }
    } else {
      lines.push(winner === 'Draw' ? '本次战斗平局，无奖励。' : '本次战斗失败，无奖励。');
    }

	    const rewardText = isWin ? `获得奖励：\n${lines.join('\n')}` : lines[0];
    const nextStage = isWin ? stage + 1 : stage;
    const nextBossTag = nextStage % 10 === 0 ? '【Boss】' : '';
    const nextLine = isWin ? `

下一关：第 ${nextStage} 关${nextBossTag}` : '';
    const desc = createText(rewardText + nextLine, 24, 0xffe3a3, '800');
    desc.anchor.set(0.5);
    desc.position.set(panelW / 2, 186);
    (desc.style as any).align = 'center';
    (desc.style as any).lineHeight = 34;
    (desc.style as any).wordWrap = true;
    (desc.style as any).wordWrapWidth = panelW - 80;

    const btnHome = new UIButton('返回主城', 320, 86);
    btnHome.position.set((panelW - 320) / 2, panelH - 160);
    btnHome.on('pointertap', () => {
      modal.close();
      this.game.goTo('home', { animate: false });
    });

    const btnAgain = new UIButton('再战一次', 320, 86);
    btnAgain.position.set((panelW - 320) / 2, panelH - 260);
    btnAgain.on('pointertap', () => {
      modal.close();
      this.startBattleFromState();
    });

    modal.content.addChild(title, desc, btnAgain, btnHome);
    modal.onClose = () => {
      modal.content.removeChildren();
    };
    modal.open();
  }
}
