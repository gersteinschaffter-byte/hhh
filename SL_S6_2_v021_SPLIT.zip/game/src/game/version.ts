// Version marker for quick build identification (update per package)
// Reset numbering from v0 (requested)
export const GAME_VERSION = 'v0.0.20';
export const BUILD_TIME = '2026-02-05 18:28';
export const DATA_VERSION = 'data-v0';
