// Version marker for quick build identification (update per package)
// Reset numbering from v0 (requested)
export const GAME_VERSION = 'v0.0.21';
export const BUILD_TIME = '2026-02-05 18:42';
export const DATA_VERSION = 'data-v0';
