# 项目结构参考报告（供写代码的 AI 参考）

> 说明：本文件用于“写代码的 AI”快速理解项目结构，并据此生成**更稳定、更少崩溃**的修改方案与补丁。  
> 原则：优先**最小改动**、**目录/模块定位明确**、**不重构不乱改**。

---

## 0) 每次改包必须遵守的“版本标识 & 交付规则”（新增）

> 目的：让你进游戏/跑起来能一眼辨认新旧包，且多 AI 协作时不互相踩踏。

### 0.1 版本号与构建时间（必须更新）
- **每次产生补丁/改动交付时，必须更新版本标识**，写在：`src/game/version.ts`
  - `GAME_VERSION`：递增（例如 v0.0.3 -> v0.0.4）
  - `BUILD_TIME`：使用 **Asia/Tokyo** 当前时间（YYYY-MM-DD HH:mm）
  - 如本次改动仅改配置，也同样要更新（方便确认“这包是新的”）。
- **允许例外修改**：即使提示词限定“只改某目录/某文件”，也允许同时修改 `src/game/version.ts`（仅用于版本标识）。

### 0.2 补丁交付格式（必须一致）
写代码 AI 交付时必须同时提供：
1) **合并后的完整包**（可直接跑/打包的完整项目）
2) **拆分后的 SPLIT 包**（保持与原 SPLIT 结构一致，便于协作与降低截断风险）

并附上“改动清单”：
- 改了哪些文件（路径列表）
- 每个文件改了什么（1 句）
- 如何运行 / 如何自测（最少 3 步）
- 若出问题如何回滚（删除哪些改动/恢复哪些文件）

#### 0.2.1 强制交付卡（短版，必须填写）

**交付卡限字规则（必须遵守）**
- 交付卡每条最多 1–2 句
- 改动文件清单最多 10 条
- 自测步骤 3–6 步
- 禁止长篇解释（不要写作文）
> 目的：不让 AI 写作文，只要你能快速验收、能回滚、能追踪版本。

- 本次目标：一句话
- 改动文件清单：≤10 条（带路径）
- 每个改动的原因：每条 ≤1 句
- 自测步骤：3～6 步（按顺序）
- 验收结果：✅/❌（对应上面的最小验收清单）
- 风险点/可能影响：存档/抽卡/背包/战斗/性能/兼容性（写有影响的）
- 回滚方法：一句话（如何恢复旧文件/旧包）
- 版本号 & 构建时间已更新：✅（并写明更新位置：`src/game/version.ts`）

### 0.3 禁止区（避免灾难性返工）
- **不重构、不大改目录结构**；除非我明确要求
- **不改初始化顺序**（`src/main.ts` / `GameApp` 启动流程保持不动）
- **不随意改 UIManager/SceneManager 的核心接口**
- **不改存档结构**（`src/game/storage.ts` 的存储 key 与数据结构保持兼容），除非我明确允许
- **不手改 dist-types/** 下生成文件（除非我明确要求）；逻辑改动优先改 `src/`，然后再按项目流程重新构建生成

### 0.4 最小验收清单（每次改动必测）
- 能启动不白屏
- 主场景能进入
- 抽卡能完成一次（出现结果弹窗）
- 背包能打开且不报错
- 战斗能开始并结束
- 重开后存档不丢

---

## 1) 项目结构和文件夹划分（做什么改哪里）

- **`src/core/`（核心框架层）**  
  管理游戏启动、场景切换、UI层级与全局状态的“骨架”。  
  常见职责：初始化 Pixi、创建舞台层级、切换场景、统一管理 UI、统一状态管理。

- **`src/scenes/`（场景/页面层）**  
  每个 `.ts` 基本对应一个“页面/功能入口”。  
  例如：主页、抽卡、英雄、背包、战斗等。  
  抽卡通常会有子目录：`src/scenes/summon/` 用于拆分 UI 子组件。

- **`src/ui/`（通用UI组件层）**  
  可复用 UI 组件与工具：按钮、顶栏、底栏、弹窗、滚动列表、Toast提示等。  
  目标是：场景里“拼组件”，组件里“画 UI”。

- **`src/game/`（玩法与数据逻辑层）**  
  配置读取、随机、存档、运行时数据整合等。  
  典型文件：  
  - `config.ts`：统一导出配置常量  
  - `data.ts`：把 heroes 等数据整理成更好用的结构（map、分组表）  
  - `random.ts`：抽卡随机与概率决定  
  - `storage.ts`：存档结构、默认存档、读写 localStorage  
  - `version.ts`：**版本号 & 构建时间标识**（每次改包必须更新，见 0.1）

- **`src/configs/`（策划配置表层 / JSON）**  
  所有策划数据都写在这里，方便改数值不改代码：  
  - `heroes.json` 英雄定义  
  - `summon_prob.json` 抽卡概率  
  - `pools.json` 卡池与消耗规则  
  - `economy.json` 经济与道具键名  
  - `battle.json` 战斗参数（如伤害波动）

- **`src/battle/`（战斗系统层）**  
  战斗通常分三块：  
  - Engine：流程推进/回合推进  
  - Logic：伤害、技能、结算等纯逻辑  
  - View：血条、伤害飘字、表现层刷新

---

## 2) 技术栈和依赖框架（它是什么做的）

- **TypeScript**：整个项目用 TS 写，且支持 `import xxx from './xxx.json'`（tsconfig 开了 `resolveJsonModule`）。  
- **Pixi.js 7.x**：2D 渲染引擎（WebGL/Canvas），使用 `Application / Container / Graphics / Text` 这些类搭 UI 和画面。  
- **Vite**：构建与开发服务器，支持热更新，打包输出 `dist`。  
- **整体形态**：Web 2D 游戏原型（Canvas/WebGL），不使用 Cocos/Laya，也不使用 React/Vue（UI 全是 Pixi 自己画的）。

---

## 3) 核心模块功能（抽卡 / 英雄 / 战斗 / 背包）

### 3.1 抽卡（召唤）系统
- **代码位置**
  - UI/交互：`src/scenes/SummonScene.ts` + `src/scenes/summon/`
  - 概率与随机：`src/game/random.ts`
  - 数据整合：`src/game/data.ts`
  - 配置表：`src/configs/summon_prob.json`, `pools.json`, `economy.json`

- **核心流程（逻辑概念）**
  1) 判断消耗：优先用召唤券，不够则用钻石（由 `pools.json` 决定）  
  2) 按 `summon_prob.json` 决定稀有度  
  3) 从该稀有度对应英雄列表中随机一个（`data.ts` 已按稀有度分组）  
  4) 新英雄加入英雄列表；重复英雄转碎片/资源（由 `economy.json` 定义补偿键名与逻辑）

### 3.2 英雄系统
- **代码位置**
  - 静态英雄表：`src/configs/heroes.json`
  - 数据整理：`src/game/data.ts`（生成 HERO_MAP / HERO_BY_RARITY 等）
  - 玩家拥有英雄：`GameState`（并在 `storage.ts` 定义 OwnedHero）
  - UI展示：`src/scenes/HeroesScene.ts` + `src/ui/components/HeroCard.ts`

- **现状与特点**
  - 有“拥有英雄”的结构（id / level / stars / obtainedAt）
  - 列表展示已实现
  - 培养升级可能预留了接口（经济参数存在，但 UI/逻辑未必完整）

### 3.3 背包/道具系统
- **代码位置**
  - 背包界面：`src/scenes/BagScene.ts`
  - 数据来源：`GameState.inventory`（键值对）
  - 道具键名来源：`src/configs/economy.json`（例如 summonTicketKey）

- **特点**
  - inventory 变化会触发事件，背包监听后自动刷新列表（典型 `inventoryChanged`）

### 3.4 战斗系统
- **代码位置**
  - 场景入口：`src/scenes/BattleScene.ts`
  - 战斗引擎：`src/battle/BattleEngine.ts`
  - 逻辑结算：`src/battle/BattleLogic.ts`
  - 表现刷新：`src/battle/BattleView.ts`
  - 技能/Buff：`SkillSystem / SkillRegistry / BuffSystem / SkillTypes / BattleTypes`

- **特点**
  - 框架划分清晰：Logic（算）/ View（显示）/ Engine（推进）
  - 战斗参数由 `battle.json` 提供（例如伤害随机范围）

---

## 4) UI 构建方式与布局系统（怎么画出来的）

- UI 基本都在 Pixi Canvas 内完成，不用 DOM（例外：竖屏提示 `#rotateTip` 属于 HTML 层）。
- UI 由组件化 Container 组合起来：
  - `UIButton` 等组件用 `Graphics` 画背景 + `Text` 写字
- **UI 层级管理**：UIManager 通常会创建多个固定层：
  - Background / Scene / UI / Popup（弹窗）等  
  目的：弹窗永远压顶，TopBar/BottomNav固定在 UI 层，不被场景遮挡。

- **布局方式**：以虚拟分辨率（如 750x1334）绝对定位为主：`position.set(x, y)`  
  优点：稳定、好控制；缺点：适配更多比例要额外写规则。

---

## 5) 数据存储与资源管理方式（数据放哪、怎么加载）

### 5.1 数据存储
- **静态配置**：全部是 `src/configs/*.json`，打包时直接进游戏，无需网络请求。  
- **运行时存档**：
  - `storage.ts` 定义 `PersistedState` 和 `defaultState()`
  - 使用 `localStorage` 保存/读取
  - `GameState` 负责内存中的状态与事件通知（如 inventoryChanged）

### 5.2 资源管理（图片/音频）
- 当前阶段几乎没有外部资源，UI主要靠 Graphics + Text。  
- 架构已预留资源加载：
  - `AssetLoader.ts` + `assetManifest.ts`
  - 将来可以通过 Pixi Assets 按 bundle 加载图片/图集/音频

---

## 5.3 项目文档（建议写代码 AI 每次同步维护）
- 现有文档：`docs/README.md`、`docs/ARCHITECTURE.md`（用于理解总体架构与约定）
- 建议新增并长期维护：
  - `docs/changelog.md`：每次改动追加一条（面向“非程序员”也能看懂）
  - `docs/decisions.md`：关键决策记录（为什么这么做）
  - `docs/research/YYYY-MM-DD_vX.Y.Z_topic.md`：深度研究/审查报告（按日期+版本命名）

> 好处：换 AI/隔一段时间回来都能快速接上，不会反复推倒重来。

---

## 6) 构建与部署流程（怎么跑、怎么打包）

- 开发：`npm run dev`（Vite 开发服务器 + 热更新）
- 打包：`npm run build`
  - `tsc` 编译 TS
  - `vite build` 打包输出到 `dist`
- 预览：`npm run preview`
- 部署：把 `dist` 放到任意静态托管即可（Web 游戏）

---

## 7) 用于生成修改补丁的“最重要规则”（建议每次都带）

写代码的 AI 在改项目时，建议提示词里包含这些固定句子：

- **限定改动范围**：只允许修改【某个目录/某个文件/某个系统】  
- **禁止乱改**：不重构、不新增文件、不改初始化顺序、不改 SceneManager/UIManager 结构  
- **数据改动原则**：玩法数值优先改 `configs/*.json`，除非必须改逻辑  
- **验收标准明确**：做到“看得到/不遮挡/数值符合/存档不丢/不卡死”才算完成  
- **最小改动优先**：如果有多方案，选择改动最小风险最低方案

---

## 8) 推荐的提示词母版（你以后直接填空即可）

- 目标：我要实现/修复【……】
- 现象：现在出现的问题是【……】
- 修改范围：只允许修改【UI/某个模块/某个目录/某个文件】
- 禁止事项：不允许【重构/改逻辑/改初始化/新增文件/改资源加载/改存档结构】
- 验收标准：做到【……】算完成（越具体越好）
- 风险控制：若有多种方案，选择【改动最小】的一种，并说明改动了哪些文件（自然语言即可）
