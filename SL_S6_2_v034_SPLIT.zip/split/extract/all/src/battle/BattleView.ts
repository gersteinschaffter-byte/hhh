import { Container, Graphics, Text } from 'pixi.js';
import type { BattleEvent, FighterSnapshot, Side } from './BattleTypes';
import { createText, roundedRect } from '../ui/uiFactory';
import { Tween, TweenRunner, easeOutCubic } from '../fx/Tween';
import { spawnFloatingText } from '../fx/FloatingText';
import { spawnFlashLine } from '../fx/FlashLine';

/**
 * BattleView
 *
 * PixiJS rendering layer.
 * - Only consumes battle events
 * - Does NOT do any numeric simulation
 */
export default class BattleView {
  public readonly root: Container;

  private readonly fighterNodes: Map<string, FighterNode> = new Map();
  private readonly fxLayer: Container;
  private readonly lineLayer: Container;
  private readonly uiLayer: Container;
  private readonly roundLabel: Text;
  private readonly resultLabel: Text;

  // Shared fx/tween runner (reused across battle effects)
  private readonly tweenRunner = new TweenRunner();

  constructor() {
    this.root = new Container();

    const arena = new Graphics();
    arena.beginFill(0x0b1533, 0.65);
    roundedRect(arena, 0, 0, 720, 900, 38);
    arena.endFill();
    arena.lineStyle(3, 0x5fa6ff, 0.35);
    roundedRect(arena, 6, 6, 708, 888, 34);
    this.root.addChild(arena);

    this.fxLayer = new Container();
    this.lineLayer = new Container();
    this.uiLayer = new Container();
    this.fxLayer.addChild(this.lineLayer);
    this.root.addChild(this.fxLayer, this.uiLayer);

    this.roundLabel = createText('回合 0', 22, 0xd7e6ff, '900');
    this.roundLabel.position.set(30, 22);
    this.uiLayer.addChild(this.roundLabel);

    this.resultLabel = createText('', 36, 0xffffff, '900');
    this.resultLabel.anchor.set(0.5);
    this.resultLabel.position.set(360, 450);
    this.resultLabel.visible = false;
    this.uiLayer.addChild(this.resultLabel);
  }

  /** Clear view and build fighters from setup. */
  public build(teamA: FighterSnapshot[], teamB: FighterSnapshot[]): void {
    // Remove old nodes
    for (const n of this.fighterNodes.values()) n.destroy();
    this.fighterNodes.clear();
    this.fxLayer.removeChildren();
    this.lineLayer.removeChildren();

    // Re-add lineLayer after clearing fxLayer
    this.fxLayer.addChild(this.lineLayer);

    // Positions (virtual arena 720x900)
    // Layout: enemy on top row (centered), player W-formation on bottom.
    const arenaW = 720;
    const arenaH = 900;
    const centerX = arenaW / 2;
    const centerY = arenaH / 2;

    const clampCount = (n: number, maxSlots: number) => Math.max(0, Math.min(maxSlots, n));

    const computeXs = (count: number, span: number) => {
      const n = Math.max(0, count);
      if (n <= 1) return [centerX];
      const step = span / (n - 1);
      const start = centerX - (step * (n - 1)) / 2;
      return Array.from({ length: n }).map((_, i) => start + step * i);
    };

    // Enemy row (top)
    const yB = centerY - arenaH * 0.26;
    const maxSlotsB = 5;
    const countB = clampCount(teamB.length, maxSlotsB);
    const xsB = computeXs(countB, Math.min(arenaW * 0.56, 520));

    // Player W-formation (bottom): frontline 2 (upper), backline 3 (lower)
    const maxSlotsA = 5;
    const countA = clampCount(teamA.length, maxSlotsA);
    const frontCount = Math.min(2, countA);
    const backCount = Math.max(0, countA - frontCount);

    const yFront = centerY + arenaH * 0.08; // closer to enemy
    const yBack = centerY + arenaH * 0.22;  // closer to bottom

    const backSpan = Math.min(arenaW * 0.62, 560);
    const frontSpan = Math.min(arenaW * 0.32, 300);

    const xsFront = computeXs(frontCount, frontSpan);
    const xsBack = computeXs(backCount, backSpan);

    const placeOne = (f: FighterSnapshot, x: number, y: number, side: Side) => {
      const node = new FighterNode(f);
      node.setHome(x, y);
      node.container.position.set(x, y);
      node.container.alpha = 0;

      // Entrance tween: slide from vertical direction for clear separation.
      node.container.y += side === 'A' ? 120 : -120;

      this.fighterNodes.set(f.id, node);
      this.fxLayer.addChild(node.container);
      this.tweenRunner.add(
        Tween.to(node.container, { y, alpha: 1 }, 18, easeOutCubic, () => {
          node.setHome(node.container.x, node.container.y);
        }),
      );
    };

    // Place player (A): indices define slots: 0-1 frontline, 2-4 backline
    for (let i = 0; i < countA; i++) {
      const f = teamA[i];
      if (!f) continue;
      if (i < frontCount) {
        placeOne(f, xsFront[i] ?? centerX, yFront, 'A');
      } else {
        const j = i - frontCount;
        placeOne(f, xsBack[j] ?? centerX, yBack, 'A');
      }
    }

    // Place enemy (B): top row centered
    for (let i = 0; i < countB; i++) {
      const f = teamB[i];
      if (!f) continue;
      placeOne(f, xsB[i] ?? centerX, yB, 'B');
    }

    this.resultLabel.visible = false;
    this.resultLabel.text = '';
    this.roundLabel.text = '回合 0';
  }

  /** Receive one battle event from logic. */
  public onEvent(e: BattleEvent): void {
    switch (e.type) {
      case 'roundStart': {
        this.roundLabel.text = `回合 ${e.payload.round}`;
        this.pulseLabel(this.roundLabel);
        break;
      }
      case 'actorTurn': {
        const node = this.fighterNodes.get(e.payload.actorId);
        if (node) node.flashTurn(this.tweenRunner); // fade-out turnGlow via TweenRunner
        break;
      }
      case 'heal': {
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (tar) tar.onHeal(e.payload.amount, e.payload.targetHp, e.payload.targetMaxHp, this.fxLayer, this.tweenRunner);
        break;
      }
      case 'damage': {
        const src = this.fighterNodes.get(e.payload.sourceId);
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (src && tar) {
          // Ensure only ONE attack line exists at a time (avoid "white lines stacking").
          this.lineLayer.removeChildren();
          spawnFlashLine(this.lineLayer, src.centerX(), src.centerY(), tar.centerX(), tar.centerY(), this.tweenRunner, {
            width: 6,
            alpha: 0.7,
            inFrames: 4,
            outFrames: 10,
          });

          tar.onDamage(e.payload.amount, e.payload.targetHp, e.payload.targetMaxHp, this.fxLayer, this.tweenRunner);
        }
        break;
      }
      case 'dead': {
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (tar) tar.playDeath(this.tweenRunner);
        break;
      }
      case 'battleEnd': {
        this.resultLabel.visible = true;
        this.resultLabel.text = e.payload.winner === 'Draw' ? '平局' : e.payload.winner === 'A' ? '我方胜利！' : '敌方胜利…';
        this.pulseLabel(this.resultLabel);
        break;
      }
      default:
        break;
    }
  }

  /** Update animations. Called by BattleEngine each tick. */
  public update(dt: number): void {
    this.tweenRunner.update(dt);
  }

  private pulseLabel(label: Text): void {
    label.scale.set(1);
    this.tweenRunner.add(
      Tween.to(label.scale, { x: 1.08, y: 1.08 }, 8, easeOutCubic, () => {
        this.tweenRunner.add(Tween.to(label.scale, { x: 1, y: 1 }, 10, easeOutCubic));
      }),
    );
  }
}

class FighterNode {
  public readonly container: Container;
  private readonly body: Graphics;
  private readonly flashOverlay: Graphics;
  private readonly hpBar: Graphics;
  private readonly nameTxt: Text;
  private readonly turnGlow: Graphics;
  private hp: number;
  private maxHp: number;

  private homeX = 0;
  private homeY = 0;
  private shakeToken = 0;
  private flashToken = 0;

  constructor(f: FighterSnapshot) {
    this.hp = f.hp;
    this.maxHp = f.maxHp;

    this.container = new Container();

    this.turnGlow = new Graphics();
    this.container.addChild(this.turnGlow);

    this.body = new Graphics();
    this.container.addChild(this.body);

    this.flashOverlay = new Graphics();
    this.flashOverlay.alpha = 0;
    this.container.addChild(this.flashOverlay);

    this.nameTxt = createText(f.name, 18, 0xffffff, '900');
    this.nameTxt.anchor.set(0.5);
    this.nameTxt.position.set(0, -62);
    this.container.addChild(this.nameTxt);

    this.hpBar = new Graphics();
    this.hpBar.position.set(-54, 52);
    this.container.addChild(this.hpBar);

    this.drawBody(f.side);
    this.drawHp();
  }

  public setHome(x: number, y: number): void {
    this.homeX = x;
    this.homeY = y;
  }

  public centerX(): number {
    return this.container.x;
  }

  public centerY(): number {
    return this.container.y;
  }

  public destroy(): void {
    this.container.destroy({ children: true });
  }

  private drawBody(side: Side): void {
    const g = this.body;
    g.clear();
    const col = side === 'A' ? 0x3aa7ff : 0xff4d6d;
    g.lineStyle(6, 0xffffff, 0.25);
    g.beginFill(col, 0.9);
    g.drawRoundedRect(-58, -48, 116, 116, 28);
    g.endFill();

    g.beginFill(0x071129, 0.3);
    g.drawCircle(0, 0, 28);
    g.endFill();

    // Flash overlay uses same silhouette but white.
    this.flashOverlay.clear();
    this.flashOverlay.beginFill(0xffffff, 0.85);
    this.flashOverlay.drawRoundedRect(-58, -48, 116, 116, 28);
    this.flashOverlay.endFill();
  }

  private drawHp(): void {
    const w = 108;
    const h = 14;
    const ratio = this.maxHp <= 0 ? 0 : Math.max(0, Math.min(1, this.hp / this.maxHp));

    this.hpBar.clear();
    this.hpBar.beginFill(0x000000, 0.35);
    roundedRect(this.hpBar, 0, 0, w, h, 10);
    this.hpBar.endFill();

    this.hpBar.beginFill(0x54ff8d, 0.9);
    roundedRect(this.hpBar, 2, 2, Math.max(0, (w - 4) * ratio), h - 4, 8);
    this.hpBar.endFill();
  }

  public flashTurn(runner: TweenRunner): void {
    // Turn glow highlight: show then fade out quickly to avoid "always on"
    this.turnGlow.clear();
    this.turnGlow.beginFill(0xffffff, 0.08);
    this.turnGlow.drawRoundedRect(-74, -64, 148, 148, 34);
    this.turnGlow.endFill();
    this.turnGlow.alpha = 1;

    // Fade out in ~0.2s (12 frames @60fps) and clear graphics when done.
    runner.add(
      Tween.to(this.turnGlow, { alpha: 0 }, 12, easeOutCubic, () => {
        this.turnGlow.clear();
      }),
    );
  }

  private playHitFlash(runner: TweenRunner): void {
    this.flashToken += 1;
    const token = this.flashToken;
    this.flashOverlay.alpha = 0.9;
    runner.add(
      Tween.to(this.flashOverlay, { alpha: 0 }, 10, easeOutCubic, () => {
        if (this.flashToken === token) this.flashOverlay.alpha = 0;
      }),
    );
  }

  private playHitShake(runner: TweenRunner): void {
    this.shakeToken += 1;
    const token = this.shakeToken;

    // Always shake around home position to avoid drifting over time.
    const ox = this.homeX;
    const oy = this.homeY;
    const dx = (Math.random() < 0.5 ? -1 : 1) * 8;
    const dy = (Math.random() < 0.5 ? -1 : 1) * 4;

    // Jump out then settle back.
    this.container.position.set(ox, oy);
    runner.add(
      Tween.to(this.container, { x: ox + dx, y: oy + dy }, 4, easeOutCubic, () => {
        runner.add(
          Tween.to(this.container, { x: ox, y: oy }, 10, easeOutCubic, () => {
            // If another shake happened after this one, don't overwrite its position.
            if (this.shakeToken === token) this.container.position.set(ox, oy);
          }),
        );
      }),
    );
  }

  public onDamage(amount: number, hp: number, maxHp: number, fxLayer: Container, runner: TweenRunner): void {
    this.hp = hp;
    this.maxHp = maxHp;
    this.drawHp();

    // Hit feedback: flash + shake + damage pop
    this.playHitFlash(runner);
    this.playHitShake(runner);
    spawnFloatingText(fxLayer, `-${amount}`, this.container.x, this.container.y - 78, runner, { life: 28, rise: 46 });
  }

  public onHeal(amount: number, hp: number, maxHp: number, fxLayer: Container, runner: TweenRunner): void {
    this.hp = hp;
    this.maxHp = maxHp;
    this.drawHp();
    spawnFloatingText(fxLayer, `+${amount}`, this.container.x, this.container.y - 78, runner, { color: 0x54ff8d });
  }

  public playDeath(runner: TweenRunner): void {
    const c = this.container;
    runner.add(
      Tween.to(c, { alpha: 0.2 }, 22, easeOutCubic, () => {
        runner.add(Tween.to(c, { alpha: 0 }, 16, easeOutCubic));
      }),
    );
  }
}
