import { Container, Graphics, Text } from 'pixi.js';
import type { BattleEvent, FighterSnapshot, Side } from './BattleTypes';
import { createText, roundedRect } from '../ui/uiFactory';
import { Tween, TweenRunner, easeOutCubic } from '../fx/Tween';
import { spawnFloatingText } from '../fx/FloatingText';
import { spawnFlashLine } from '../fx/FlashLine';
import { getBuffJson } from './SkillDefs';

// Skill-type color mapping for visual variety.
const SKILL_COLORS: Record<string, number> = {
  sk_fireball:  0xff6633,
  sk_sweep:     0xffaa22,
  sk_heal:      0x54ff8d,
  sk_aura_heal: 0x88ffcc,
  sk_warcry:    0xff4444,
  sk_shield:    0x66ccff,
  sk_poison:    0xcc44ff,
  sk_slow:      0x44ddff,
};
const DEFAULT_SKILL_COLOR = 0xffee88;

/**
 * BattleView
 *
 * PixiJS rendering layer.
 * - Only consumes battle events
 * - Does NOT do any numeric simulation
 */
export default class BattleView {
  public readonly root: Container;

  private readonly fighterNodes: Map<string, FighterNode> = new Map();
  private readonly fxLayer: Container;
  private readonly uiLayer: Container;
  private readonly roundLabel: Text;
  private readonly resultLabel: Text;

  private readonly roundBg: Graphics;

  private readonly logBg: Graphics;
  private readonly logText: Text;
  private readonly logLines: string[] = [];


  // Shared fx/tween runner (reused across battle effects)
  private readonly tweenRunner = new TweenRunner();

  constructor() {
    this.root = new Container();

    const arena = new Graphics();
    arena.beginFill(0x0b1533, 0.65);
    roundedRect(arena, 0, 0, 720, 900, 38);
    arena.endFill();
    arena.lineStyle(3, 0x5fa6ff, 0.35);
    roundedRect(arena, 6, 6, 708, 888, 34);
    this.root.addChild(arena);

    this.fxLayer = new Container();
    this.uiLayer = new Container();
    this.root.addChild(this.fxLayer, this.uiLayer);

    this.roundBg = new Graphics();
    this.uiLayer.addChild(this.roundBg);

    this.roundLabel = createText('回合 0', 28, 0xffffff, '900');
    this.roundLabel.position.set(24, 18);
    this.uiLayer.addChild(this.roundLabel);
    this.updateRoundPill();

    // Battle log strip (last few actions)
    this.logBg = new Graphics();
    this.logBg.position.set(16, 808);
    this.uiLayer.addChild(this.logBg);

    this.logText = createText('', 16, 0xd7e6ff, '700');
    this.logText.position.set(28, 818);
    this.uiLayer.addChild(this.logText);
    this.renderLog();

    this.resultLabel = createText('', 36, 0xffffff, '900');
    this.resultLabel.anchor.set(0.5);
    this.resultLabel.position.set(360, 450);
    this.resultLabel.visible = false;
    this.uiLayer.addChild(this.resultLabel);
  }

  /** Returns true if there are running tweens/FX animations. */
  public isAnimating(): boolean {
    return !this.tweenRunner.isIdle();
  }


  /** Clear view and build fighters from setup. */
  public build(teamA: FighterSnapshot[], teamB: FighterSnapshot[]): void {
    this.logLines.length = 0;
    this.renderLog();
    // Remove old nodes
    for (const n of this.fighterNodes.values()) n.destroy();
    this.fighterNodes.clear();
    this.fxLayer.removeChildren();

    // Positions (virtual arena 720x900)
    // Layout: enemy on top row (centered), player on bottom row (centered).
    const arenaW = 720;
    const arenaH = 900;
    const centerX = arenaW / 2;
    const centerY = arenaH / 2;

    const maxSpan = 560; // max horizontal span used for formation
    const maxSlotsA = 5; // player must support up to 5
    const maxSlotsB = 5; // allow up to 5 for future-proof; typically enemies are fewer

    const computeXs = (count: number) => {
      const n = Math.max(0, count);
      if (n <= 1) return [centerX];
      const step = Math.min(140, maxSpan / (n - 1));
      const start = centerX - (step * (n - 1)) / 2;
      return Array.from({ length: n }).map((_, i) => start + step * i);
    };

    // More "confrontational" spacing: enemy higher, player lower.
    const yB = centerY - 160;
    const yA = centerY + 170;

    const placeTeam = (team: FighterSnapshot[], side: Side) => {
      const maxSlots = side === 'A' ? maxSlotsA : maxSlotsB;
      const count = Math.min(maxSlots, team.length);
      const xs = computeXs(count);
      for (let i = 0; i < count; i++) {
        const f = team[i]!;
        const x = xs[i] ?? centerX;
        const y = side === 'A' ? yA : yB;
        const node = new FighterNode(f);
        node.container.position.set(x, y);
        node.container.alpha = 0;
        // Entrance tween: slide from vertical direction for clear top/bottom separation.
        node.container.y += side === 'A' ? 120 : -120;
        this.fighterNodes.set(f.id, node);
        this.fxLayer.addChild(node.container);
        this.tweenRunner.add(Tween.to(node.container, { y, alpha: 1 }, 18, easeOutCubic));
      }
    };

    placeTeam(teamA, 'A');
    placeTeam(teamB, 'B');
    this.resultLabel.visible = false;
    this.resultLabel.text = '';
    this.roundLabel.text = '回合 0';
  }

  /** Receive one battle event from logic. */
  public onEvent(e: BattleEvent): void {
    switch (e.type) {
      case 'roundStart': {
        this.roundLabel.text = `回合 ${e.payload.round}`;
        this.updateRoundPill();
        this.pulseLabel(this.roundLabel);
        this.pushLog(`—— 回合 ${e.payload.round} ——`);
        break;
      }
      case 'actorTurn': {
        this.setActiveActor(e.payload.actorId);
        const node = this.fighterNodes.get(e.payload.actorId);
        if (node) node.flashTurn(this.tweenRunner);
        const name = node ? node.getName() : e.payload.actorId;
        this.pushLog(`${name} 行动`);
        break;
      }
      case 'skillUse': {
        const node = this.fighterNodes.get(e.payload.actorId);
        if (node) {
          this.pushLog(`${node.getName()} 使用【${e.payload.skillName}】`);
          const color = SKILL_COLORS[e.payload.skillId] ?? DEFAULT_SKILL_COLOR;
          // Skill name floating text above the actor.
          spawnFloatingText(
            this.fxLayer,
            `【${e.payload.skillName}】`,
            node.container.x,
            node.container.y - 100,
            this.tweenRunner,
            { color, fontSize: 22, rise: 50, life: 30 },
          );
          // Quick body flash in skill color.
          node.flashColor(color, this.tweenRunner);
        }
        break;
      }
      case 'heal': {
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (tar) {
          tar.onHeal(e.payload.amount, e.payload.targetHp, e.payload.targetMaxHp, this.fxLayer, this.tweenRunner);
          // Green glow ring around healed target.
          this.spawnRing(tar.container.x, tar.container.y, 0x54ff8d);
          this.pushLog(`${tar.getName()} +${e.payload.amount}`);
        }
        break;
      }
      case 'damage': {
        const src = this.fighterNodes.get(e.payload.sourceId);
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (src && tar) {
          // Self-damage (DoT) — no attack line, just purple damage number.
          if (e.payload.sourceId === e.payload.targetId) {
            tar.onDamage(e.payload.amount, e.payload.targetHp, e.payload.targetMaxHp, this.fxLayer, this.tweenRunner, 0xcc44ff);
          } else {
            src.playAttackTo(tar.container.x, tar.container.y, this.fxLayer, this.tweenRunner);
            tar.onDamage(e.payload.amount, e.payload.targetHp, e.payload.targetMaxHp, this.fxLayer, this.tweenRunner);
          }
        }
        // Log
        if (tar) {
          const tname = tar.getName();
          if (e.payload.sourceId === e.payload.targetId) this.pushLog(`${tname} 受到持续伤害 -${e.payload.amount}`);
          else {
            const sname = src ? src.getName() : e.payload.sourceId;
            this.pushLog(`${sname} → ${tname} -${e.payload.amount}`);
          }
        }
        break;
      }
      case 'buffAdd': {
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (tar) {
          const def = getBuffJson(e.payload.buffId);
          const icon = def?.icon ?? '✦';
          const name = def?.name ?? e.payload.buffId;
          tar.addBuffIcon(e.payload.buffId, icon);
          spawnFloatingText(this.fxLayer, `${icon}${name}`, tar.container.x, tar.container.y - 90, this.tweenRunner, { color: 0xffee88, fontSize: 20 });
          this.pushLog(`${tar.getName()} 获得 ${icon}${name}`);
        }
        break;
      }
      case 'buffRemove': {
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (tar) tar.removeBuffIcon(e.payload.buffId);
        break;
      }
      case 'dead': {
        const tar = this.fighterNodes.get(e.payload.targetId);
        if (tar) {
          tar.playDeath(this.tweenRunner);
          this.pushLog(`${tar.getName()} 倒下了`);
        }
        break;
      }
      case 'battleEnd': {
        this.resultLabel.visible = true;
        this.resultLabel.text = e.payload.winner === 'Draw' ? '平局' : e.payload.winner === 'A' ? '我方胜利！' : '敌方胜利…';
        this.pulseLabel(this.resultLabel);
        this.pushLog(`结果：${this.resultLabel.text}`);
        break;
      }
      default:
        break;
    }
  }


  private updateRoundPill(): void {
    const padX = 14;
    const padY = 8;
    const w = Math.max(120, this.roundLabel.width + padX * 2);
    const h = Math.max(38, this.roundLabel.height + padY * 2);

    this.roundBg.clear();
    this.roundBg.beginFill(0x000000, 0.28);
    roundedRect(this.roundBg, 14, 12, w, h, 16);
    this.roundBg.endFill();

    this.roundBg.lineStyle(2, 0x5fa6ff, 0.25);
    roundedRect(this.roundBg, 14, 12, w, h, 16);

    // Keep text inside the pill.
    this.roundLabel.position.set(14 + padX, 12 + padY - 1);
  }

  private pushLog(line: string): void {
    if (!line) return;
    this.logLines.push(line);
    while (this.logLines.length > 5) this.logLines.shift();
    this.renderLog();
  }

  private renderLog(): void {
    // Draw bg
    const w = 720 - 32;
    const h = 78;
    this.logBg.clear();
    this.logBg.beginFill(0x000000, 0.25);
    roundedRect(this.logBg, 0, 0, w, h, 18);
    this.logBg.endFill();
    this.logBg.lineStyle(2, 0x5fa6ff, 0.18);
    roundedRect(this.logBg, 0, 0, w, h, 18);

    this.logText.text = this.logLines.join('\n');
  }

  private setActiveActor(actorId: string): void {
    for (const [id, n] of this.fighterNodes.entries()) {
      // Dim non-active fighters slightly so the current actor pops.
      const isActive = id === actorId;
      n.container.alpha = isActive ? 1 : 0.72;
    }
  }


  /** Update animations. Called by BattleEngine each tick. */
  public update(dt: number): void {
    this.tweenRunner.update(dt);
  }

  /** Expanding ring effect (heal glow, AOE indicator). */
  private spawnRing(x: number, y: number, color: number, radius = 60): void {
    const ring = new Graphics();
    ring.lineStyle(4, color, 0.7);
    ring.drawCircle(0, 0, 10);
    ring.position.set(x, y);
    ring.alpha = 0.9;
    this.fxLayer.addChild(ring);

    // Animate: scale up + fade out.
    const targetScale = radius / 10;
    this.tweenRunner.add(
      Tween.to(ring, { alpha: 0 }, 20, easeOutCubic, () => ring.destroy()),
    );
    this.tweenRunner.add(
      Tween.to(ring.scale, { x: targetScale, y: targetScale }, 20, easeOutCubic),
    );
  }

  private pulseLabel(label: Text): void {
    label.scale.set(1);
    this.tweenRunner.add(
      Tween.to(label.scale, { x: 1.08, y: 1.08 }, 8, easeOutCubic, () => {
        this.tweenRunner.add(Tween.to(label.scale, { x: 1, y: 1 }, 10, easeOutCubic));
      }),
    );
  }
}

class FighterNode {
  public readonly container: Container;
  private readonly body: Graphics;
  private readonly hpBar: Graphics;
  private readonly nameTxt: Text;
  private readonly baseName: string;
  private readonly turnGlow: Graphics;
  private readonly buffBar: Container;
  private readonly buffIcons = new Map<string, Text>();
  private hp: number;
  private maxHp: number;

  constructor(f: FighterSnapshot) {
    this.baseName = f.name;
    this.hp = f.hp;
    this.maxHp = f.maxHp;

    this.container = new Container();

    this.turnGlow = new Graphics();
    this.container.addChild(this.turnGlow);

    this.body = new Graphics();
    this.container.addChild(this.body);

    this.nameTxt = createText(f.name, 18, 0xffffff, '900');
    this.nameTxt.anchor.set(0.5);
    this.nameTxt.position.set(0, -62);
    this.container.addChild(this.nameTxt);

    this.hpBar = new Graphics();
    this.hpBar.position.set(-54, 52);
    this.container.addChild(this.hpBar);

    // Buff icon row below HP bar.
    this.buffBar = new Container();
    this.buffBar.position.set(-54, 70);
    this.container.addChild(this.buffBar);

    this.drawBody(f.side);
    this.drawHp();
  }

  public destroy(): void {
    this.container.destroy({ children: true });
  }

  public getName(): string {
    return this.baseName || this.nameTxt.text || '';
  }

  private drawBody(side: Side): void {
    const g = this.body;
    g.clear();
    const col = side === 'A' ? 0x3aa7ff : 0xff4d6d;
    g.lineStyle(6, 0xffffff, 0.25);
    g.beginFill(col, 0.9);
    g.drawRoundedRect(-58, -48, 116, 116, 28);
    g.endFill();

    g.beginFill(0x071129, 0.3);
    g.drawCircle(0, 0, 28);
    g.endFill();
  }

  private drawHp(): void {
    const w = 108;
    const h = 14;
    const ratio = this.maxHp <= 0 ? 0 : Math.max(0, Math.min(1, this.hp / this.maxHp));

    this.hpBar.clear();
    this.hpBar.beginFill(0x000000, 0.35);
    roundedRect(this.hpBar, 0, 0, w, h, 10);
    this.hpBar.endFill();

    this.hpBar.beginFill(0x54ff8d, 0.9);
    roundedRect(this.hpBar, 2, 2, Math.max(0, (w - 4) * ratio), h - 4, 8);
    this.hpBar.endFill();
  }

  public addBuffIcon(buffId: string, icon: string): void {
    if (this.buffIcons.has(buffId)) return;
    const t = createText(icon, 16, 0xffffff, '700');
    this.buffIcons.set(buffId, t);
    this.buffBar.addChild(t);
    this.layoutBuffIcons();
  }

  public removeBuffIcon(buffId: string): void {
    const t = this.buffIcons.get(buffId);
    if (!t) return;
    this.buffBar.removeChild(t);
    t.destroy();
    this.buffIcons.delete(buffId);
    this.layoutBuffIcons();
  }

  private layoutBuffIcons(): void {
    let x = 0;
    for (const t of this.buffIcons.values()) {
      t.position.set(x, 0);
      x += 22;
    }
  }

  /** Quick body tint flash in a given color (used for skill activation). */
  public flashColor(color: number, runner: TweenRunner): void {
    const overlay = new Graphics();
    overlay.beginFill(color, 0.35);
    overlay.drawRoundedRect(-58, -48, 116, 116, 28);
    overlay.endFill();
    overlay.alpha = 1;
    this.container.addChild(overlay);
    runner.add(Tween.to(overlay, { alpha: 0 }, 14, easeOutCubic, () => {
      this.container.removeChild(overlay);
      overlay.destroy();
    }));
  }

    public flashTurn(runner: TweenRunner): void {
    // Turn glow highlight: show then fade out quickly to avoid "always on"
    this.turnGlow.clear();
    this.turnGlow.beginFill(0xfff4a0, 0.16);
    this.turnGlow.drawRoundedRect(-74, -64, 148, 148, 34);
    this.turnGlow.endFill();
    this.turnGlow.alpha = 1;

    // Fade out in ~0.35s and clear graphics when done.
    runner.add(
      Tween.to(this.turnGlow, { alpha: 0 }, 20, easeOutCubic, () => {
        this.turnGlow.clear();
      }),
    );
  }

  public playAttackTo(tx: number, ty: number, fxLayer: Container, runner: TweenRunner): void {
    spawnFlashLine(fxLayer, this.container.x, this.container.y, tx, ty, runner);
  }

  public onDamage(amount: number, hp: number, maxHp: number, fxLayer: Container, runner: TweenRunner, dmgColor?: number): void {
    this.hp = hp;
    this.maxHp = maxHp;
    this.drawHp();

    // Shake
    const ox = this.container.x;
    runner.add(
      Tween.to(this.container, { x: ox + 12 }, 4, easeOutCubic, () => {
        runner.add(Tween.to(this.container, { x: ox }, 8, easeOutCubic));
      }),
    );

    // Floating damage text (use custom color for DoT, etc.)
    spawnFloatingText(fxLayer, `-${amount}`, this.container.x, this.container.y - 78, runner, dmgColor != null ? { color: dmgColor } : undefined);
  }

  public onHeal(amount: number, hp: number, maxHp: number, fxLayer: Container, runner: TweenRunner): void {
    this.hp = hp;
    this.maxHp = maxHp;
    this.drawHp();
    spawnFloatingText(fxLayer, `+${amount}`, this.container.x, this.container.y - 78, runner, { color: 0x54ff8d });
  }

  public playDeath(runner: TweenRunner): void {
    const c = this.container;
    runner.add(
      Tween.to(c, { alpha: 0.2 }, 22, easeOutCubic, () => {
        runner.add(Tween.to(c, { alpha: 0 }, 16, easeOutCubic));
      }),
    );
  }
}
