import type { BattleEventEmitter, BattleSetup, FighterSnapshot, Side } from './BattleTypes';
import type { SkillRuntimeAPI } from './SkillTypes';
import { BATTLE } from '../game/config';
import SkillSystem from './SkillSystem';
import BuffSystem from './BuffSystem';
import { SkillRegistry, BuffRegistry } from './SkillRegistry';
import { getBuffJson, getSkillName } from './SkillDefs';

/**
 * BattleLogic — pure simulation layer (no Pixi).
 *
 * v0.0.31 changes:
 * - Registries are public so BattleEngine can populate them.
 * - getSkillApi() returns an extended surface (getAtk / ally / enemy helpers).
 * - Buff stat mods (atkPct, dmgReduce, spdFlat) are applied in combat.
 * - DoT (poison etc.) ticks at round start.
 */
export default class BattleLogic {
  private readonly emitter: BattleEventEmitter;
  private readonly rng: () => number;

  // Public so BattleEngine can register skills/buffs from JSON config.
  public readonly skillRegistry = new SkillRegistry();
  public readonly buffRegistry = new BuffRegistry();
  private readonly skillSystem = new SkillSystem(this.skillRegistry);
  private readonly buffSystem = new BuffSystem(this.buffRegistry);

  private round = 0;
  private over = false;

  // Step state: we advance one actor action per step() for clear pacing.
  private phase: 'idle' | 'turns' = 'idle';
  private turnOrder: string[] = [];
  private turnIndex = 0;

  private teamA: FighterSnapshot[] = [];
  private teamB: FighterSnapshot[] = [];

  constructor(emitter: BattleEventEmitter, rng?: () => number) {
    this.emitter = emitter;
    this.rng = rng ?? Math.random;
  }

  public init(setup: BattleSetup): void {
    this.round = 0;
    this.over = false;
    this.phase = 'idle';
    this.turnOrder = [];
    this.turnIndex = 0;
    this.teamA = setup.teamA.map((f) => ({ ...f }));
    this.teamB = setup.teamB.map((f) => ({ ...f }));
    this.buffSystem.init([...this.teamA, ...this.teamB]);

    this.emitter.emit({
      type: 'battleStart',
      payload: {
        teamA: this.teamA.map((f) => ({ ...f })),
        teamB: this.teamB.map((f) => ({ ...f })),
      },
    });

    // onBattleStart skill triggers (e.g. warcry).
    const api = this.getSkillApi();
    for (const f of [...this.teamA, ...this.teamB]) {
      this.emitSkillFired(f.id, this.skillSystem.tryTrigger('onBattleStart', f, { round: 0, actorId: f.id }, api));
    }
  }

  public runToEnd(maxRounds = 30): void {
    // Safety runner for debugging: keep stepping until battle ends or maxRounds reached.
    // With per-actor stepping, cap total steps by an upper bound.
    const maxSteps = maxRounds * 32; // enough for typical party sizes
    for (let i = 0; i < maxSteps && !this.over; i++) this.step();
    if (!this.over) this.finish('Draw');
  }

  /**
   * Advance simulation by ONE actor action.
   * Each step performs:
   * - (when starting a new round) roundStart + DoT + onRoundStart skills + build turn order
   * - (during turns) a single actorTurn (onTurnStart skills + basic attack + resulting buffs)
   */
  public step(): void {
    if (this.over) return;

    // Start a new round if needed.
    if (this.phase === 'idle' || this.turnIndex >= this.turnOrder.length) {
      this.beginRound();
      // beginRound may end the battle (DoT / aura etc.)
      if (this.over) return;
    }

    // Execute exactly one alive actor action per step.
    while (this.turnIndex < this.turnOrder.length && !this.over) {
      const actorId = this.turnOrder[this.turnIndex++];
      const actor = this.findFighterById(actorId);
      if (!actor || actor.hp <= 0) continue;

      const api = this.getSkillApi();
      this.emitter.emit({ type: 'actorTurn', payload: { round: this.round, actorId: actor.id } });

      // 1) Turn-start skills (if any fire, they consume this step's action).
      const firedOnTurnStart = this.skillSystem.tryTrigger('onTurnStart', actor, { round: this.round, actorId: actor.id }, api);
      this.emitSkillFired(actor.id, firedOnTurnStart);

      // 2) Turn-start DoT ticks (poison-per-turn, etc.)
      this.applyBuffDotsFor(actor.id, 'turn');
      this.checkBattleEnd();
      if (this.over) break;

      // 3) If no skill fired, fall back to a basic attack.
      if (firedOnTurnStart.length === 0) {
        this.performBasicAttack(actor);
      }

      this.checkBattleEnd();
      break; // Only one actor action per step.
    }

    // If we exhausted the turn list, next step will begin a new round.
    if (!this.over && this.turnIndex >= this.turnOrder.length) {
      this.phase = 'idle';
      if (this.round >= 30) this.finish('Draw');
    }
  }

  public isOver(): boolean { return this.over; }
  public getRound(): number { return this.round; }

  // ── Round orchestration ──────────────────────────

  private beginRound(): void {
    if (this.over) return;

    this.round += 1;
    this.emitter.emit({ type: 'roundStart', payload: { round: this.round } });
    this.buffSystem.onRoundStart(this.round);

    // DoT ticks (poison etc.)
    this.applyBuffDots();
    this.checkBattleEnd();
    if (this.over) return;

    // onRoundStart skill triggers (e.g. aura heal)
    const api = this.getSkillApi();
    for (const f of this.getAllAlive()) {
      this.emitSkillFired(f.id, this.skillSystem.tryTrigger('onRoundStart', f, { round: this.round, actorId: f.id }, api));
    }
    this.checkBattleEnd();
    if (this.over) return;

    // Sort by effective SPD (buff-aware) and store turn order for this round.
    this.turnOrder = this.getAllAlive()
      .sort((a, b) => this.getEffectiveSpd(b) - this.getEffectiveSpd(a) || a.id.localeCompare(b.id))
      .map((f) => f.id);
    this.turnIndex = 0;
    this.phase = 'turns';
  }

  private findFighterById(id: string): FighterSnapshot | undefined {
    return [...this.teamA, ...this.teamB].find((f) => f.id === id);
  }


  // ── Attack ─────────────────────────────────────────

  private performBasicAttack(actor: FighterSnapshot): void {
    const enemyTeam = actor.side === 'A' ? this.teamB : this.teamA;
    const targets = enemyTeam.filter((t) => t.hp > 0);
    if (targets.length === 0) return;

    const target = this.chooseTarget(actor, targets);
    const api = this.getSkillApi();

    this.emitSkillFired(actor.id, this.skillSystem.tryTrigger('onBeforeAttack', actor, { round: this.round, actorId: actor.id, targetId: target.id }, api));

    // Damage = (effectiveATK × variance - effectiveDEF × 0.3), then reduced by target's dmgReduce buffs.
    const variance = BATTLE.damageVarianceMin + this.rng() * (BATTLE.damageVarianceMax - BATTLE.damageVarianceMin);
    const effectiveAtk = this.getEffectiveAtk(actor);
    const effectiveDef = this.getEffectiveDef(target);
    const rawDmg = Math.floor(effectiveAtk * variance - effectiveDef * 0.3);
    const reduction = this.getDmgReduction(target);
    const dmg = Math.max(1, Math.floor(rawDmg * (1 - reduction)));

    this.emitSkillFired(actor.id, this.skillSystem.tryTrigger('onBeforeDamage', actor, { round: this.round, actorId: actor.id, targetId: target.id }, api));
    this.dealDamage(actor.id, target.id, dmg);
    this.emitSkillFired(actor.id, this.skillSystem.tryTrigger('onAfterDamage', actor, { round: this.round, actorId: actor.id, targetId: target.id }, api));
    this.emitSkillFired(actor.id, this.skillSystem.tryTrigger('onAfterAttack', actor, { round: this.round, actorId: actor.id, targetId: target.id }, api));
  }

  // ── Skill API (extended) ───────────────────────────

  private getSkillApi(): SkillRuntimeAPI {
    return {
      dealDamage: (s, t, a) => this.dealDamage(s, t, a),
      heal:       (s, t, a) => this.heal(s, t, a),
      addBuff:    (s, t, b, n) => this.addBuff(s, t, b, n ?? 1),
      removeBuff: (t, b) => this.removeBuff(t, b),
      // Extended helpers used by SkillDefs effects.
      getAtk: (id: string) => {
        const f = this.findFighter(id);
        return f ? this.getEffectiveAtk(f) : 0;
      },
      getAliveEnemyIds: (id: string) => {
        const f = this.findFighter(id);
        if (!f) return [];
        return (f.side === 'A' ? this.teamB : this.teamA).filter((t) => t.hp > 0).map((t) => t.id);
      },
      getAliveAllyIds: (id: string) => {
        const f = this.findFighter(id);
        if (!f) return [];
        return (f.side === 'A' ? this.teamA : this.teamB).filter((t) => t.hp > 0).map((t) => t.id);
      },
      getLowestHpAllyId: (id: string) => {
        const f = this.findFighter(id);
        if (!f) return undefined;
        const alive = (f.side === 'A' ? this.teamA : this.teamB).filter((t) => t.hp > 0);
        if (alive.length === 0) return undefined;
        alive.sort((a, b) => (a.hp / a.maxHp) - (b.hp / b.maxHp));
        return alive[0]!.id;
      },
    } as any;
  }

  // ── Buff stat helpers ──────────────────────────────

  private getEffectiveAtk(f: FighterSnapshot): number {
    let atk = f.atk;
    for (const bi of this.buffSystem.getBuffs(f.id)) {
      const bdef = getBuffJson(bi.id);
      const mod = bdef?.statMod;
      if (mod?.atkFlat) atk += mod.atkFlat * bi.stacks;
      if (mod?.atkPct) atk = Math.floor(atk * (1 + mod.atkPct * bi.stacks));
    }
    return Math.max(0, Math.floor(atk));
  }

  private getEffectiveDef(f: FighterSnapshot): number {
    let df = f.def ?? 0;
    for (const bi of this.buffSystem.getBuffs(f.id)) {
      const bdef = getBuffJson(bi.id);
      const mod = bdef?.statMod;
      if (mod?.defFlat) df += mod.defFlat * bi.stacks;
      if (mod?.defPct) df = Math.floor(df * (1 + mod.defPct * bi.stacks));
    }
    return Math.max(0, Math.floor(df));
  }

  private getDmgReduction(f: FighterSnapshot): number {
    let r = 0;
    for (const bi of this.buffSystem.getBuffs(f.id)) {
      const def = getBuffJson(bi.id);
      if (def?.statMod?.dmgReduce) r += def.statMod.dmgReduce * bi.stacks;
    }
    return Math.min(0.75, r);
  }

  private getEffectiveSpd(f: FighterSnapshot): number {
    let spd = f.spd;
    for (const bi of this.buffSystem.getBuffs(f.id)) {
      const def = getBuffJson(bi.id);
      if (def?.statMod?.spdFlat) spd += def.statMod.spdFlat * bi.stacks;
    }
    return Math.max(1, spd);
  }

  private applyBuffDots(): void {
    for (const f of this.getAllAlive()) {
      this.applyBuffDotsFor(f.id, 'round');
    }
  }

  private applyBuffDotsFor(fighterId: string, tick: 'round' | 'turn'): void {
    const f = this.findFighter(fighterId);
    if (!f || f.hp <= 0) return;
    for (const bi of this.buffSystem.getBuffs(f.id)) {
      const def = getBuffJson(bi.id);
      const dot = def?.dot;
      const dotTick = dot?.tick ?? 'round';
      if (dot?.hpPct && dotTick === tick) {
        const dmg = Math.max(1, Math.floor(f.maxHp * dot.hpPct * bi.stacks));
        this.dealDamage(f.id, f.id, dmg);
      }
    }
  }

  // ── Skill event emission ────────────────────────────

  private emitSkillFired(actorId: string, firedIds: string[]): void {
    for (const id of firedIds) {
      this.emitter.emit({ type: 'skillUse', payload: { actorId, skillId: id, skillName: getSkillName(id) } });
    }
  }

  // ── Primitives ─────────────────────────────────────

  private findFighter(id: string): FighterSnapshot | undefined {
    return [...this.teamA, ...this.teamB].find((f) => f.id === id);
  }

  private dealDamage(sourceId: string, targetId: string, amount: number): void {
    const target = this.findFighter(targetId);
    if (!target || target.hp <= 0) return;
    const a = Math.max(1, Math.floor(amount));
    target.hp = Math.max(0, target.hp - a);
    this.emitter.emit({ type: 'damage', payload: { sourceId, targetId, amount: a, targetHp: target.hp, targetMaxHp: target.maxHp } });
    if (target.hp <= 0) this.emitter.emit({ type: 'dead', payload: { targetId } });
  }

  private heal(sourceId: string, targetId: string, amount: number): void {
    const target = this.findFighter(targetId);
    if (!target || target.hp <= 0) return;
    const a = Math.max(1, Math.floor(amount));
    target.hp = Math.min(target.maxHp, target.hp + a);
    this.emitter.emit({ type: 'heal', payload: { sourceId, targetId, amount: a, targetHp: target.hp, targetMaxHp: target.maxHp } });
  }

  private addBuff(sourceId: string, targetId: string, buffId: string, stacks = 1): void {
    this.buffSystem.addBuff(sourceId, targetId, buffId, stacks, this.round);
    this.emitter.emit({ type: 'buffAdd', payload: { sourceId, targetId, buffId, stacks } });
  }

  private removeBuff(targetId: string, buffId: string): void {
    this.buffSystem.removeBuff(targetId, buffId);
    this.emitter.emit({ type: 'buffRemove', payload: { targetId, buffId } });
  }

  private checkBattleEnd(): void {
    const aAlive = this.teamA.some((f) => f.hp > 0);
    const bAlive = this.teamB.some((f) => f.hp > 0);
    if (aAlive && bAlive) return;
    if (aAlive && !bAlive) this.finish('A');
    else if (!aAlive && bAlive) this.finish('B');
    else this.finish('Draw');
  }

  private finish(winner: Side | 'Draw'): void {
    if (this.over) return;
    this.over = true;
    this.emitter.emit({ type: 'battleEnd', payload: { winner } });
  }

  private getAllAlive(): FighterSnapshot[] {
    return [...this.teamA, ...this.teamB].filter((f) => f.hp > 0);
  }
}
