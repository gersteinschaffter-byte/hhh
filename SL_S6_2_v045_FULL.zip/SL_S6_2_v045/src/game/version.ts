// Version marker for quick build identification (update per package)
// Reset numbering from v0 (requested)
export const GAME_VERSION = 'v0.0.45';
export const BUILD_TIME = '2026-02-08 02:10';
export const DATA_VERSION = 'data-v1';
