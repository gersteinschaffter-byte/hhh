#!/data/data/com.termux/files/usr/bin/bash
set -e

# Usage:
#   bash termux_clean_run.sh /sdcard/Download/SL_S6_2_v0xx_FULL.zip
# If zip path is not provided, it will try to auto-pick the newest SL_S6_2_*FULL*.zip in Download.

termux-setup-storage >/dev/null 2>&1 || true

ZIP="${1:-}"
if [ -z "$ZIP" ]; then
  ZIP="$(ls -t /sdcard/Download/SL_S6_2_*FULL*.zip 2>/dev/null | head -n 1 || true)"
fi

if [ -z "$ZIP" ] || [ ! -f "$ZIP" ]; then
  echo "[clean_run] ERROR: zip not found."
  echo "[clean_run] Put the FULL zip into /sdcard/Download and rerun, or pass it as an argument."
  exit 1
fi

echo "[clean_run] Using zip: $ZIP"

pkg update -y >/dev/null
pkg install -y unzip nodejs-lts >/dev/null

RUN_DIR="$HOME/game/SL_run"
rm -rf "$RUN_DIR"
mkdir -p "$RUN_DIR"
cd "$RUN_DIR"

unzip -o "$ZIP" -d . >/dev/null

PROJ_DIR="$(find . -maxdepth 3 -type f -name package.json -printf '%h\n' | head -n 1)"
if [ -z "$PROJ_DIR" ]; then
  echo "[clean_run] ERROR: package.json not found after unzip (zip may be broken)."
  exit 1
fi
cd "$PROJ_DIR"

bash ./verify_project.sh

npm install
npm run dev -- --host 0.0.0.0 --port 5173
