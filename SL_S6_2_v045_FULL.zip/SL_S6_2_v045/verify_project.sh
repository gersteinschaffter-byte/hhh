#!/data/data/com.termux/files/usr/bin/bash
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "[verify] project root: $ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "[verify] ERROR: node not found. Install with: pkg install -y nodejs-lts"
  exit 1
fi

NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "[verify] ERROR: Node >= 18 required. Current: $(node -v)"
  exit 1
fi

need_files=(
  "package.json"
  "vite.config.ts"
  "src/main.ts"
  "src/scenes/BattleScene.ts"
  "src/battle/BattleEngine.ts"
  "src/battle/BattleLogic.ts"
)

missing=0
for f in "${need_files[@]}"; do
  if [ ! -f "$f" ]; then
    echo "[verify] MISSING: $f"
    missing=1
  fi
done

if [ "$missing" -ne 0 ]; then
  echo "[verify] ERROR: Project files are incomplete."
  echo "[verify] Tip: Don't unzip over an old folder. Use termux_clean_run.sh to run from a clean directory."
  exit 1
fi

echo "[verify] OK"
